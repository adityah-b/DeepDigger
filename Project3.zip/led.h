// LED support

// Written by Bernie Roehl, February 2017

void LED_setup(void);
void LED_set(int n);
void LED_clear(int n);
void LED_display(unsigned char n);
